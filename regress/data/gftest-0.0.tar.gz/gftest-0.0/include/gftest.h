void headertest(void);
void typetest(void);
