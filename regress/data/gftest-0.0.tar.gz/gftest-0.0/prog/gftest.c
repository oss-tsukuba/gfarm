#include <stdio.h>
#include <stdlib.h>

#include "config.h"
#include "gftest.h"

int
main(int argc, char **argv)
{
#ifdef HAVE_GETLOADAVG
	double loadavg[3];
	int i, n = getloadavg(loadavg, sizeof(loadavg)/sizeof(loadavg[0]));

	for (i = 0; i < n; i++)
		printf("loadavg[%d] = %g\n", i, loadavg[i]);
#endif
	headertest();
	typetest();

	return 0;
}
