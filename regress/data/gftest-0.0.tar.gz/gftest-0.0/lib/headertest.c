#include "config.h"
#include "gftest.h"

void
headertest(void)
{
}
