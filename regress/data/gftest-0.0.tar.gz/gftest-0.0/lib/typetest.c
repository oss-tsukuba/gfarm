#include <stdio.h>

#include "config.h"
#include "gftest.h"

void
typetest(void)
{
#ifdef SIZEOF_LONG
	printf("sizeof(long) = %d / %d\n",
	    (int)sizeof(long), (int)SIZEOF_LONG);
#endif
#ifdef SIZEOF_LONG_LONG
	printf("sizeof(long long) = %d / %d\n",
	    (int)sizeof(long long), (int)SIZEOF_LONG_LONG);
#endif
	printf("sizeof(size_t) = %d\n", (int)sizeof(size_t));
}
